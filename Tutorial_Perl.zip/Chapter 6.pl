=code
									CHAPTER 6 : FILES AND DATA
https://docs.google.com/viewer?url=http://blob.perl.org/books/beginning-perl/3145_Chap06.pdf
=cut

#!/usr/bin/perl -w
use warnings;
use strict;

# 1- standard filehandles
# 	 	<STDIN> : reads single lines from keyboard 
#		<STDOUT> : print STDOUT "Hello\n" 
#		<STDERR> : write errors when we die  

# 2 - open : 
#		MY_FH : name of filehandle
#		"/temp" : directory
#		$! : special variable which holds the errormessage sent from the system
#		\n : if not set at end, perl puts name of program and location
# open MY_FH, "/temp" or die "Error : $!\n"; -> Error here

# 3 - Diamond operator (readline operator) : <>
# <MY_FH> : reads one line from filehandle
=code
print "3 - -------------------------\n";
open FILE, "Chapter6.txt" or die $!; #open file and make sure it''s opened
my $lineno = 1;
while (<FILE>) { #read one line, equivalent to : while (defined ($_ = <FILE>))
	chomp;
	print $lineno++;
	print ": $_\n"; #no need to add a newline actually, if u dont chomp, cause it comes from the file 
					#but last line coming from the file must have the newline, which in most cases fails
}
=cut 

# 4 - Special filehandle : ARGV -> reads the names of files from the command line and opens them all
#								-> to read a single line use <ARGV> or just <>
=code
print "4 - -------------------------\n";
$lineno = 1;
while (<>) { #read one line from @ARGV : perl "Chapter 6.pl" Chapter6.txt Chapter6_2.txt
	chomp;
	print $lineno++;
	print ": $_\n"; 
}

print "\nCurrent file name in ARGV is ", $ARGV, "\n"; # $ARGV : shows the current file name
=cut

# 4-1 - detecting when ARGV changes : resetting the line number 
=code
print "4-1 - -------------------------\n";
my $lineno = 1;
my $current = "";

while (<>) { #read one line from @ARGV : 
	if ($current ne $ARGV) {
		$current = $ARGV;
		$lineno = 1;		
	}
	chomp;
	print $lineno++;
	print ": $_\n"; 
}
=cut

# 5 - Reading more then one line
=code
open INPUT, "file.dat" or die $!;
my @data;
@data = <INPUT>; ----> reads all at once : memory-intensive
=cut

=code
open FILE, "dict.txt" or die $!;
my @lines = <FILE>;
print "Last 5 lines from small files:\n", @lines[-5 ... -1];

# reading the last five lines in a file
open FILE, "dict.txt" or die $!;
my @last5;

while(<FILE>) {
	push @last5, $_; #add to the end
	shift @last5 if @last5 > 5; #take from the beginning
}
print "Last 5 lines from big files: \n", @last5;
=cut

# 5-1 - Skip a part of FILE
=code
$targetText = "standard\.def"; #in lynx
$_ = <FILE> until /$targetText/;
=cut


# 6 - Special character : record seperator $/ --> mostly defined as \n -a seperator of readed lines (records)- can be redefined
# 						: record : lines which ll be read till seperator (most cases \n) 
=code
$/ = "\n%%\n";
open FILE, "Chapter6_3.txt" or die $!;
my @file = <FILE>;
my $fortune = $file[rand(@file)]; #a random number between 0 - @file (size)
chomp $fortune;
print $fortune, "\n";
=cut

# 7 - Reading paragraphs at a time : put $/ = "";
=code
$/ = "";
while (<>) {
	print ((split /\n/, $_)[0]); #prints the first lines till "\n" of a paragraph, thus u can print first line of all paragraphs
}
=cut

# 8 - Reading entire file in a string
=code
$/ = undef;
open FILE, "dict.txt" or die $!;
my $file = <FILE>;
print $file;
=cut

# 9 Writing to file
=code
open FILE, "> dict2.txt" or die $!; --> open for writing in, reset the file, erase all
open FILE, ">> dict3.txt" or die $!; --> open for writing in, add to the end of file, dont erase anything
open FILE, "< dict2.txt" or die $!; --> this is actually open for reading
=cut

# 9-1 Copy a file : perl x dict.txt dict_copy.txt
=code
my $sour = shift; # same as shift @ARGV; or @ARGV[0]
my $dest = shift; # same as shift @ARGV; or @ARGV[1]

open IN,  "< $sour" or die "Can't open file $sour...! $!\n";
open OUT, "> $dest" or die "Can't open file $dest...! $!\n";

while (<IN>) {
	print OUT $_; # --> to write into a file use "print OUT_FH"
}
=cut

# 9-2 Sorting the file : ASCII or NUMERIC
=code
my $numeric = 0; #default by ASCII
my $input = shift;

if ($input eq "-n") {
	$numeric = 1; #turn to NUMERIC
	$input = shift;
}

my $output = shift;

open IN,  "< $input" or die "Can't open file $input...! $!\n";
open OUT, "> $output" or die "Can't open file $output...! $!\n";

my @fileData = <IN>;

if ($numeric) {
	#perl x.pl -n Chapter6_4.txt Chapter6_4_sort_num.txt
	@fileData = sort { $a <=> $b } @fileData; #numeric sort on arrays
} else {
	#perl x.pl Chapter6_4.txt Chapter6_4_sort_ascii.txt
	@fileData = sort @fileData; #ascii sort on arrays
}

print OUT @fileData;
=cut

# 9-2 Sorting the file v2 : ASCII or NUMERIC - from/to file or STDIN/STDOUT

# perl x.pl < sortme.txt
=code
my $numeric = 0; #default by ASCII
my $input = shift;

if (defined $input and $input eq "-n") { #if input given
	$numeric = 1; #turn to NUMERIC
	$input = shift;
}

my $output = shift;

if (defined $input) {
	open INPUT,  "< $input" or die "Can't open file $input...! $!\n";
} else {
	*INPUT = *STDIN; # * : globs, look like pointers
}

if (defined $output) {
	open OUTPUT, "> $output" or die "Can't open file $output...! $!\n";	
} else {
	*OUTPUT = *STDOUT;
}

my @fileData = <INPUT>;

if ($numeric) {
	#perl x.pl -n Chapter6_4.txt Chapter6_4_sort_num.txt
	@fileData = sort { $a <=> $b } @fileData; #numeric sort on arrays
} else {
	#perl x.pl Chapter6_4.txt Chapter6_4_sort_ascii.txt
	@fileData = sort @fileData; #ascii sort on arrays
}

print OUTPUT @fileData;
=cut

# 10 - Writing binary data
# open the file with --> binmode FILEHANDLE

# 11 - Selecting a filehandle : default print uses STDOUT as filehandle, we can replace it with ours
=code
my $logging = "screen"; #write "file" inorder to write into a file

if ($logging eq "file") {
	open LOG, "> output.log" or die $!;
	select LOG; #print ll use this as default
}

print "Program started: ", scalar localtime, "\n";
sleep 2;
print "Program finished: ", scalar localtime, "\n";

select STDOUT; #dont forget to define STDOUT back
=cut

# 12 - Buffering : $|
=code : 
most OSs prints the dots after 20 secs at once, this is because they use buffering to avoid 
a lot of short read's and write's for single shots, queue up in a buffer and access the filehandle at once
this can be changed with the special chatacter $|

but this is working for me, because ActivePerl does this as it s wished
for (1...20) {
	print "."; 
	sleep 1;
}

change the intervall
$| = 1; ----------> don't forget to select the filehandle, if not to write to STDOUT
for (1...20) {
	print "."; 
	sleep 1;
}
=cut

# 13 - Opening pipes
=code
my %inventory;
print "Enter inventoeris\n"; #enter a blank line to finish

while (1) {
	my $item = <STDIN>;
	chomp $item;
	last unless $item; #read until blank line
	$inventory{lc $item}++;
}

open (SORT, "| perl sort.pl") or *SORT = *STDOUT;
select *SORT;
while (my ($item, $quantity) = each %inventory) {
	if ($quantity > 1) {
		$item =~ s/^(\w+)\b/$1's/ unless $item =~ /^\w+'s\b/; #add a 's to end for pluratiy
	}
	print "$item: $quantity\n";
}
=cut

# 14 - File Tests
=code
if (-e "filename.txt") {...}

-e : True if file exists
-f : True if file is a plain file, not a directory
-d : True if file is a directory
-z : True if file has zero size
-s : True if file has nonzero size
-r, -w, -x, -o : UNIX, if file readable, writable, ... usw!
=cut

# 15 - Directories

# 15-1 - globbing : *, ? e.g. dir *.txt or dir ?ail
=code
my @files = glob("C*.txt");
print "Matched : @files\n";
=cut

# 15-2 Reading directories
# opendir DIRHAND, "." or die "...$!";
=Code
print "opening current directory\n";
opendir DH, "." or die $!;
while ($_ = readdir(DH)) {
	next if $_ eq "." or $_ eq "..";
	print $_, " " x (40-length($_));
	print -s _ if -f _; # _ is default file handle for filetests -> refers to the last file explicitly tested
	print "\n",
}
=cut
































