$txt = "#include dd";
$txt =~ s/\#include/\/\/\#include/;
print $txt;

=c
use strict;
use warnings;

# Matrix mit den IDs und Namen aller SCs
my @matSCInfos;
# Flag : SC IDs und Namen werden dann gelesen, wenn $startReadingSCNames = 1 wird
# d.h. in der Datei diese Stelle erreicht ist
my $startReadingSCNames = 0;
# Flag : Zuerst werden die IDs und die Namen der SCs gelesen solange $scInfoRead = 0 ist
my $scInfoRead = 0;

# SCXML Datei lesen
my $FILE_Scxml = "D:\\Temp\\scxml_tests\\21_scs_man.scxml";
open(SCXML, "$FILE_Scxml") or die $!;
my @SCs = <SCXML>;
chomp @SCs;
close SCXML;

# Diese ist fest
$matSCInfos[0][0] = "-";
$matSCInfos[0][1] = "Systemkonstanten";

# Anzahl SCs
my $numSCs = 0;
# Counter f�r Zeilen von matrix. Erste Zeile beinhaltet die Titel.
my $row;
# Counter f�r Spalten von matrix : 
# - Erste ist die SC-ID, zweite der SC-Name
# 1 ist deswegen weil bei einem <SC-Combinations> wird $col schon um 1 erh�ht
my $col = 1;
# Name der Kombination
my $kombiName;

# <SCID> gelesen?
my $idRead = 0;
# <Name> gelesen ?
my $nameRead = 0;
for (0..$#SCs)
{
	my $lineSCxml = $SCs[$_];
	
	# Diese if-Abfragen durchf�hren, nur wenn die SC IDs und Namen noch nicht gelesen sind
	if ($scInfoRead == 0)
	{
		# Zuerst die IDs und die Namen der SCs lesen
		if ($lineSCxml =~ /<SC-Definitions>/)
		{
			$startReadingSCNames = 1;
		}
		elsif ($lineSCxml =~ /<\/SC-Definitions>/)
		{
			# Die ersten Informationen fertig gelesen
			$scInfoRead = 1;
		}
		
		if ($startReadingSCNames == 1)
		{
			if ($lineSCxml =~ /<SCID>/)
			{
				chomp $lineSCxml;
				$lineSCxml =~ s/ //g; #Spaces entfernen
				$lineSCxml =~ s/<SCID>//;
				$lineSCxml =~ s/<\/SCID>//;
				$row = $lineSCxml; #Zeile
				$matSCInfos[$row][0] = $lineSCxml; #ID
				$idRead = 1;
			}
			if ($lineSCxml =~ /<Name>/)
			{
				chomp $lineSCxml;
				$lineSCxml =~ s/ //g; #Spaces entfernen
				$lineSCxml =~ s/<Name>//;
				$lineSCxml =~ s/<\/Name>//;
				$matSCInfos[$row][1] = $lineSCxml; # Name
				$nameRead = 1;
			}
			if ($idRead == 1 and $nameRead == 1)
			{
				$numSCs++;
				$idRead = 0; # Flag zur�cksetzen
				$nameRead = 0; # Flag zur�cksetzen
			}
		}
	}
	else
	{
		# Neue Spalte f�r eine neue Kombination
		if ($lineSCxml =~ /<SC-Combination Name=\"(.+)\">/)
		{
			++$col;
			$matSCInfos[0][$col] = $1;
		}
		
		# Die Ref-ID ist wichtig, weil auch gemischte Reihenfolge vorkommt		
		if ($lineSCxml =~ /<SCID-Ref>/)
		{
			chomp $lineSCxml;
			$lineSCxml =~ s/ //g; #Spaces entfernen
			$lineSCxml =~ s/<SCID-Ref>//;
			$lineSCxml =~ s/<\/SCID-Ref>//;
			$row = $lineSCxml;
		}
		if ($lineSCxml =~ /<Value>/)
		{
			chomp $lineSCxml;
			$lineSCxml =~ s/ //g; #Spaces entfernen
			$lineSCxml =~ s/<Value>//;
			$lineSCxml =~ s/<\/Value>//;
			$matSCInfos[$row][$col] = $lineSCxml;
		}
	}
}

# Print matrix
for my $i (0..$numSCs)
{
	for my $index ( 0..$#{ $matSCInfos[$i] } )
	{
		print $matSCInfos[$i][$index], " ";
	}
	print "\n";
}


##my $command = "im issues --fields=MSG_SE_Verantwortliche_Person_Codetest 629137";
#
#$mksPath = "/MSG/LimTqEl/01_PROD/04_TSI_LimTqEl/20_SWE_LimTqEl/01_PROD/04_SWI/project.pj";
#$cpNo = "1.71";
#my $command = "si viewproject --project=$mksPath --projectRevision=$cpNo --fields labels --forceConfirm=\"no\"";
#my $resultConnectIM = `$command`;
#
#print $resultConnectIM;
## Check, ob eine Verbindung zu MKS gibt
#my $commandConnectIM = "im servers"; # Displays the current connections to an MKS Integrity Server
#my $resultConnectIM = `$commandConnectIM`;
#
#print $resultConnectIM, "\n";
#if ($resultConnectIM eq "" or $resultConnectIM =~ /Not connected/)
#{
#	print "not connext";
#}
#else
#{
#	# Es gibt Verbindung
#	print "connext";
#}
# Fork - Child
#my $command = "si connect --hostname=\"mksprod.in.audi.vwg\" --port=7001";
#$result = `$command2`;
#$mksPath = "/MSG/LimTqEl/01_PROD/04_TSI_LimTqEl/20_SWE_LimTqEl/01_PROD/04_SWI/project.pj";
#$cpNo = "1.71";
#
#unless (defined ($pid = fork())) {
#    die "cannot fork: $!";
#}
#unless ($pid) { #child
#	$command2 = "si viewproject --project \"$mksPath\" --projectRevision=$cpNo --fields labels --forceConfirm=\"no\"";
#	print "command call\n";
#	$result = `$command2`;
#	print $result, "\n";
#}
#
#sleep 3;
#kill (9, $pid);
#
#print "parent cont\n";
# MKS
#my $mksPath = "/MSG/LimTqEl/01_PROD/04_TSI_LimTqEl/20_SWE_LimTqEl/01_PROD/04_SWI/project.pj";
#my $cpNo = "1.71";
#my $command = "si viewproject --project \"$mksPath\" --projectRevision=$cpNo --fields labels --forceConfirm=\"no\"";
##
#my $result = `$command2`;
###my $result = exec($command2);
###my $result = system($command2);
#print "..",$result;

=c
## Kill process

#$process = "ImpAdd.Exe                    6604 RDP-Tcp#0                  2        55.704 K";
##my @processes = `tasklist`;
##foreach (@processes)
##{
##	my $process = $_;
##	if ($process =~ /ImpAdd/)
##	{
##		print "ia found : \n$process\n";
#		
#		if ($process =~ /.*([0-9][0-9][0-9][0-9]).*/)
#		{
#			print "id $1";
#			#kill (-9, $1);
#		}
##	}
##}


###########


##!/usr/bin/perl
#
#use strict;
#use warnings;
#use File::Copy;
#
#my $source_dir  = "D:/Temp/Src";
#my $target_dir  = "D:/Temp/Dst";
#
#mkdir($target_dir) or die "Could not mkdir $target_dir: $!";



############


#!/usr/local/bin/perl -w

#use warnings;
#use strict;
#use Tk;
#use threads;
#use threads::shared;

#
##############
### Globals ##
##############
#my $shared_text:   shared = "";        # The message sent back to the parent
#my $shared_flag:   shared = 0;        # 0 = no msg waiting, 1 = msg waiting
#
#
###################
### Main program ##
###################
#
#my $pthread = threads->new(\&worker_thread);
#$pthread->detach();
#
#my $mw = MainWindow->new();
#my $text = $mw->Entry(-width => 8)->pack();
#
#$text->insert(0, 'abcde');
#
#my $button = $mw->Button(-text=>'click', -command => \&talk_to_worker)->pack();
#MainLoop;
#
#
##################
### Subroutines ##
##################
#
## Parent subroutines
#sub talk_to_worker{
#    while (0 == $shared_flag) {
#        print "(parent)  Waiting for flag to go to 1\n";
#        #select(undef, undef, undef, 0.5);
#        sleep(1);
#    }
#
#    my $msg = $shared_text;
#    print "(parent)  Got message '$msg'\n";
#
#    if ($msg) {
#        $text->delete('0.0', "end");
#        $text->insert('0.0', $msg);
#        $mw->update();
#    }
#
#    print "(parent)  Resetting flag to 0\n";
#    $shared_flag = 0;
#}
#
#
#
## Worker subroutines
#sub worker_thread {
#    for my $i (0..100) {
#        sleep 3;
#        send_message_to_parent("-$i");
#    }
#}
#
#
#sub send_message_to_parent {
#    my ($msg) = @_;
#
#    # Wait until the $shared_flag is zero again
#    while (1 == $shared_flag) {
#        print "(worker)  Waiting for flag to go to 0\n";
#        #select(undef, undef, undef, 0.5);
#        sleep(1);
#    }
#
#    # Send the message;
#    $shared_text = $msg;
#
#    # Raise the flag to handshake with the parent
#    $shared_flag = 1;
#}

#use warnings;
#use strict;
#
#use Time::HiRes qw(usleep);
#
#
#my $fileName = "D:\\Alakese\\xx.log";
#my $i = 0;
#
##open (my $fh, ">>", $fileName);
#open (OUT, ">>", $fileName);
#
#while($i < 10) {
#	print $i++, "\n";
#	
##	if ($fh)
##	{
##	  print $fh "Test_$i\n";
#	  #close ($fh);
##	}
#	print OUT "Test_$i\n";
#	sleep(1);
#}
#
#close OUT;


=c
#use Log::Log4perl qw(:easy);
use Log::Log4perl qw(get_logger :levels);
use Log::Log4perl::Appender::Screen;

Log::Log4perl->init(\<<CONFIG);
log4perl.rootLogger = DEBUG, screen, file

log4perl.appender.screen = Log::Log4perl::Appender::Screen
log4perl.appender.screen.stderr = 0
log4perl.appender.screen.layout = PatternLayout
log4perl.appender.screen.layout.ConversionPattern = %d %p> %F{1}:%L %M - %m%n

log4perl.appender.file = Log::Log4perl::Appender::File
log4perl.appender.file.filename = 1.log
log4perl.appender.file.mode = append
log4perl.appender.file.layout = PatternLayout
log4perl.appender.file.layout.ConversionPattern = %d %p> %F{1}:%L %M - %m%n
CONFIG

my $logger = get_logger();
$logger->level($INFO);
        
drink();
drink("Soda");
    
sub drink {
	my($what) = @_;
	
	if(defined $what) {
  	$logger->info("Drinking ", $what);
	} else {
		$logger->error("No drink defined");
	}
}
    
=c
my $dir = "C:/Temp/temp.log";

#open (DIR, $dir) or $! = 42; die "Can not open file!";
#my @arr = <DIR>;
#close DIR;

if (!(open (DIR, $dir))) {
	print "Can not open file!";
	exit 42;
} 
my @arr = <DIR>;
close DIR;


=c

my $file = "D:\\Alakese\\MKS\\Minilink\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h";
my $fileOut = "D:\\Alakese\\MKS\\Minilink\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen_defines.h";
my $fileOut2 = "D:\\Alakese\\MKS\\Minilink\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen_founds.h";

open (SERVICES, "< $file") or die "Reading error: $!";
our @FileList_UsedServices=<SERVICES>;
close SERVICES;

my @testArr;
my $ctEntries = 0;
#open (OUT, "> $fileOut") or die "Reading error: $!";
foreach(@FileList_UsedServices) {
	if (/^\#define (.*)_ASCET/) {
		++$ctEntries;
		#print OUT $_,"\n";
		push @testArr, $_;
	}	
}
#close OUT;

print "Found : $ctEntries entries\n";

my $ctMEntries = 0;
#open (IN, "< $fileOut") or die "Reading error: $!";
#@FileList_UsedServices=<IN>;
#close IN;

open (OUT2, "> $fileOut2") or die "Reading error: $!";

my $lineno = 0;
foreach my $line (@testArr) {
			chomp $line;
			if ($line =~ /COUNTDOWN_U8_compute_ASCET/) {
				print "kkkk";
			}
			print OUT2 "->> $lineno : $line\n";
        # Note the ()() for enable use of $1
        if ($line =~ m/([\w]*_ASCET *\()(.*)/) 
        {
        	      
          $st_LibCall = $1;
          
          my $st_LibCall_Tmp = $st_LibCall;

          # Remove "_ASCET (" / "_ASCET("
          $st_LibCall =~ s/_ASCET \(//g;
          $st_LibCall =~ s/_ASCET\(//g;

          if ($st_LibCall =~ m/_compute/)
          {
            my $st_LibCall_Compute = $st_LibCall;
            $st_LibCall_Compute =~ s/_[Cc]ompute//g;
            if ( !(grep(/^$st_LibCall_Compute$/, @rgst_LibCallsFromCFiles)) ) # check if not already in list...
            {
              push(@rgst_LibCallsFromCFiles, $st_LibCall_Compute);
              print OUT2 "---->>_Compute \(".$lineno."\): $st_LibCall_Compute\n";
              ++$ctMEntries;
            }
          }
          elsif ($st_LibCall =~ m/_out/)
          {          
            my $st_LibCall_Out = $st_LibCall;
            $st_LibCall_Out =~ s/_[Oo]ut//g;
            if (!(grep(/^$st_LibCall_Out$/, @rgst_LibCallsFromCFiles)))
            {
              push(@rgst_LibCallsFromCFiles, $st_LibCall_Out);
              print OUT2 "---->>_out \(".$lineno."\):     $st_LibCall_Out\n";
              ++$ctMEntries;
            }
          }
          elsif ($st_LibCall =~ m/_reset/)
          {
            my $st_LibCall_Reset = $st_LibCall;
            $st_LibCall_Reset =~ s/_[Rr]eset//g;
            if (!(grep(/^$st_LibCall_Reset$/, @rgst_LibCallsFromCFiles)))
            {
              push(@rgst_LibCallsFromCFiles, $st_LibCall_Reset);
              print OUT2 "---->>_Reset \(".$lineno."\):   $st_LibCall_Reset\n";
              ++$ctMEntries;
            }
          }
          else
          {
            $st_LibCall =~ s/_[0-9a-zA-Z]*$//g;
            if (!(grep(/^$st_LibCall/, @rgst_LibCallsFromCFiles)))
            {
              $st_LibCall_Tmp = "$st_LibCall";
              push(@rgst_LibCallsFromCFiles, $st_LibCall);
              print OUT2 "---->>Non standard LibCall \(".$lineno."\): \"$st_LibCall\"\n";
              ++$ctMEntries;
            }
          }
        }
        ++$lineno;
}
close OUT2;

print "Found : $ctMEntries entries 2\n";


=c
my $services = "D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_services.h";
my $types = "uint8|uint16|uint32|sint8|sint16|sint32|real32";

# Lies services 
open (SERVICES, "< $services") or die "Cant open : $!";
my @services; 
while (defined (my $line = <SERVICES>)) {
	if ($line =~ /^#include\s*\"(.*).c/)
	{
		chomp $line;
		push @services, $1;
	}
}
close SERVICES;

open (FH_CODEGEN, "< D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h") or die "Reading error: $!";
my @file = <FH_CODEGEN>;
close (FH_CODEGEN) or die "Closing failure:, $!";

open (SAVE, "> C:\\Dokumente und Einstellungen\\ealakes\\Desktop\\new2.c") or die "Reading error: $!";

#remove types in datei, um die Suche zu erleichtern
map{s/\b$types\b//g} @file;

my @calledServices;
my $i = 0;
my $multiLine = 0;

foreach my $line (@file) {
	chomp $line; #remove \n
	
	if ($line =~ /\s*?[\/\*|\*]/) {
		next;
	}
	
#	if ($line =~ /LOWPASST_DT_U16_compute_ASCET/) {
#		print "Ok\n";
#	}

	# falls es nicht zu einer Multiline-Zeile geh�rt
	if ($multiLine == 0) {
		# dann nimm nur #define's
		unless ($line =~ /^#define/) {
			next;
		}
	}

	# Falls makro multi-line geschrieben ist, dann ist \ am Ende, einfach skip diese Zeile, damit Fkt-Name gesucht werden kann
	if ($line =~ /\\$/) {
		$multiLine = 1;
		next;
	}
	
	my @words = quotewords('\s+', 0, $line);
	
	foreach my $word (@words)
	{
		if (defined($word) and $word =~ /(\w+)/) {
			my $searchText = $1;
  		# Manche services haben _calc, _read oder _write im Namen, aber so hei�t die Headerdatei nicht
			# Bsp: RingBuffer_U08_write_VW -> steht in RingBuffer_U08_VW.c : !!!ENTFERNEN!!!
			$searchText =~ s/_calc|_read|_write//;

			# Es gibt Services, die unterschiedliche klein-gross Buchstaben haben : z.B. Lowpass vs. LowPass
			my @searchResult = grep {/\b$searchText\b/i} @services;
			# Falls geparste Service in AUDI_ASCET_services.h gefunden
			if ( @searchResult and !(grep {/$searchText/} @calledServices) ) {
				# dann speichern
				push @calledServices, $searchResult[0];
				#multiline-flag zur�cksetzen
				if ($multiLine == 1) {
					$multiLine = 0;
				}		
			}
		}
	}	
}

print SAVE @calledServices;

close (SAVE) or die "Closing failure:, $!";

print "finisched";
