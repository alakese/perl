=code
									CHAPTER 8 : SUBROUTINES
https://docs.google.com/viewer?url=http://blob.perl.org/books/beginning-perl/3145_Chap08.pdf
=cut

#!/usr/bin/perl -w
use warnings;
#use strict;

my $option = shift; #argv

# 1 - Subroutines declaration 
 
sub version {
	print "Version 2.0\n";
}
version if $option eq "-v";

# Order of declaration
# calling a subroutine as above has limitation ; declare subroutine before use it OR use ()

version2() if $option eq "-v";
sub version2 {
	print "Version 2.0a\n";
}
 
# Forward definition
sub version3;

version3 if $option eq "-v";

sub version3 {
	print "Version 2.0b\n";
}

# use keyword

use warnings;
use subs qw(version version2 version3 version4);

version4 if $option eq "-v";

sub version4 {
	print "Version 2.0c\n";
}

# Ampersand
&version4;


# 2 - Subroutines for calculation

# Parameters : @_ params as lists
total (1..100); #we can pass any list 
total (10, 20, 30);
sub total {
	my $total = 0;
	$total += $_ for (@_);
#	for (@_) { #add each elem of it
#		$total += $_;
#	}
	print "Total = $total\n";
}


# Return values : implicitly or explicitly

# implicit
my $total = total2 (10, 20, 30);
print "implicit ", $total, "\n";
sub total2 {
	my $total = 0;
	$total += $_ for @_;
	$total;
}

#
my ($hours, $minutes) = getTime(3723);
print "Implicit:$hours:$minutes\n";
sub getTime {
	my $seconds = shift;
	my $h = int $seconds/3600; 
	$seconds %= 3600;
	my $m = int $seconds/60;
	($h, $m);
}

# explicit : keyword return 
sub getTime2 {
	my $seconds = shift;
	my $h = int $seconds/3600; 
	$seconds %= 3600;
	my $m = int $seconds/60;
	return ($h, $m);			# ----->
}


# 3 - Caching : make subroutine calculate faster...! see example

# 4 - Context : caller or wantarray

my ($hours2, $minutes2) = getTime3(3723); 	# -> array context
print "array: ".$hours2.":".$minutes2."\n";
my $time = getTime3(6868);				 	# -> scalar context
print $time, "\n";

sub getTime3 {
	my $seconds = shift;
	my $h = int $seconds/3600; 
	$seconds %= 3600;
	my $m = int $seconds/60;
	if (wantarray) { 						#--> if return value must be an array
		return ($h, $m);	
	}
	return "$h hours, $m minutes";
}

# 5 - Subroutine prototypes : prototypes talk about number of scalars we allow, use $ for each one

sub sum_of_two_squares($$); # use a forward definition for perl to read prototype
print sum_of_two_squares(2, 2), "\n";
#print sum_of_two_squares(2, 2, 2);
sub sum_of_two_squares($$) {
	my ($a, $b) = (shift, shift);
	return $a**2+$b**2;
}

# 6 - Global variables
# packages : all variables with no 'my' are defined in package 'main'

$main::name   = "Your Name Here";
$Fred::name   = "Fred Flintstone";
$Barney::name = "Barney Rubble";

print "\$name in package main   is $name\n";
print "\$name in package Fred   is $Fred::name\n";
print "\$name in package Barney is $Barney::name\n";

print "\$name in package main   is $name\n";
package Fred;
print "\$name in package Fred   is $name\n";
package Barney;
print "\$name in package Barney is $name\n";
package main;

# 7 - local : global variables can be used for a local scope without changing its original value

#to understand the difference between lexical variables and local
my $x = 10;
$_ = "alpha";
{
	my $x = 20;
	local $_ = "beta";
	somesub();
}
somesub();

sub somesub {
	print "\$x is $x\n";
	print "\$_ is $_\n";
}

# 8 - Passing more complex parameters

# @_ provides aliases like $_

# what s alias
@array = (1, 2, 3, 4);
for (@array) {
	$_++; 
}
print @array, "\n"; #affects the array elements => 2, 3, 4, 5 
#---

sub add_one_and_double {
	$_[0]++;
	return $_[0]*2;
}

#add_one_and_double(1); #here error, because of trying to change the value of a constant

# therefore copy it lo a local with "shift" (common usage)
# 1- my @args = @_;
# 2- my ($filename, $title) = @_;
# 3- my $filename = shift;
#	 my $title = shift;

# each subroutine has its own copy of @_
first (1, 2, 3);

sub first {
	print "first ", @_,"\n";
	second(4, 5, 6);
	print "first ", @_,"\n";
}

sub second {
	print "second ", @_, "\n";
}


# 9 - Passing references to a subroutine

# scalar
my $a = 5;
increment(\$a);			# here we give a ref as param
print $a, "\n";
sub increment {
	my $reference = shift;
	$$reference++;
}

#or with prototype
sub increment2 (\$); 	# ref to a scalar, for ex. ($\%$) means scalar, ref to hash, scalar
increment2($a); 		# here must be a scalar, not a ref to a scalar 
print $a, "\n";
sub increment2 (\$) {
	my $reference = shift;
	$$reference++;
}

# arrays, hashes
sub check_same (\@\@); # check two arrays -> we cant use arrays as params, because they will collapse, so use references

my @a = (1, 2, 3, 4, 5);
my @b = (2, 1, 3, 4, 5);
my @c = (1, 2, 3, 4, 5);
print "\@a same as \@b" if check_same (@a, @b), "\n";
print "\@a same as \@c" if check_same (@a, @c), "\n";

sub check_same (\@\@) {
	$ref_one = shift;
	$ref_two = shift;
	
	return 0 unless @$ref_one == @$ref_two; #same size?
	
	for my $elem (0..$#$ref_one) {
		return 0 unless $ref_one->[$elem] eq $ref_two->[$elem];
	}
	return 1;#same
}


# 10 - Passing filehandles to a subroutine

# a
sub say_hello {
	*WHERE = shift;
	print WHERE "Hello\n";
}
say_hello (*STDOUT);

# b
=code
sub hello {
	my $fh = shift;
	print $fh "Hello2\n";
}

sub get_line {
	my $fh = shift;
	my $response = <$fh>;
	chomp $response;
	$response =~ s/^\s+//;
	return $response;
}

hello(*STDOUT);
print get_line(*STDIN);
=cut

# 11 - Default parameter values with ||

sub log_warning {
	my $message = shift || "error";
	my $time = shift || localtime; # default param is now localtime
	print "[$time] $message\n"; 
}

log_warning ("XXX", "Date:333");
log_warning ("YYY"); #def time
log_warning();


# 12 - Named parameters : name the parameters if u forget the order of them

logon ( name => "Username", pass => "Password"); #can be thought as hashes
sub logon {
	my %args = @_;
	print "12 - $args{name} : $args{pass}\n";
}


# 13 - References to subroutines + CALLBACKS (using subroutines as parameters to functions)
# sub something {...}
# my $ref = \&something();

#calling
#&{$ref} OR &{$ref}(@parameters) OR &$ref(@parameters) OR $ref->();

# Example for ref to subroutines : program to select menu

my %menu = (
	c => \&customer_menu,
	s => \&sales_menu
	#...
);

print "Type c for customer, s for sales, ... : ";
chomp (my $choice = <>);
if (exists $menu{$choice}) {
	$menu{$choice}->();				# here we dont need to ask for : if ($choice eq "c") {...} elsif ($choice eq s) {...} ...
} else {
	#...error
}


























