=code : custom closed -> go to custom_3

use warnings;
use strict;

my $services = "D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_services.h";
my $types = "uint8|uint16|uint32|sint8|sint16|sint32|real32";
my $internElements = "counter|buffer|memory|Memory|timeCounter|deltaTvariable|inOld|time|outbit|initValue|oldValue|oldSignal|hysterese|hysteresis|rampActive|PointerArray|tGsCalc|tWallCalc|pwrHeatWallEnvCalc|dstLockStrt|noDrvCycLock|dstLock|gradient|Input_Storage|Index_Counter|MinCount|MaxCount|mem|Nxt|Prs|pos_int";
my $keywords = "const|if|_SC_VW";
my $nums = "[0-9]*";
my $octs = "0x[a-fA-F0-9]*";
my $unsLongs = "[0-9]*UL";

open (SERVICES, "< $services") or die "Cant open : $!";
my @services; 
while (defined (my $line = <SERVICES>)) {
	if ($line =~ /^#include\s*\"(.*).c/)
	{
		chomp $line;
		push @services, $1;
	}
}
close SERVICES;

open (FH_CODEGEN, "< D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h") or die "Reading error: $!";
my @file = <FH_CODEGEN>;
close (FH_CODEGEN) or die "Closing failure:, $!";

open (SAVE, "> C:\\Dokumente und Einstellungen\\ealakes\\Desktop\\new2.c") or die "Reading error: $!";

#remove types
map{s/\b$types\b//g} @file;

#remove intern elems
map{s/\b$internElements\b//g} @file;

#remove keywords
map{s/\b$keywords\b//g} @file;

#remove numbers
map{s/\b$nums\b//g} @file;

#remove ULs
map{s/$unsLongs//g} @file;

#remove octs
map{s/$octs//g} @file;

#remove params
my @calledServices;

my $Debug = 0;

foreach my $line (@file) {
	if ($line =~ /COUNTARRAYOUTOFMINMAX/) {
		$Debug && print "Ok";
	}
	
	#convert tabs to a space, weil zwischen Parameterende und Inhalt gibt es unterschiedliche leer-spaces
	#$line =~ s/\s/ /g;
	if ($line =~ /#define (.*)_ASCET(\(.*\)) (.*)/) {
		my $parameter = $2;
		my $rumpf = $3;
		$parameter =~ s/\(|\)//g;
		my @params = split(/\,/, $parameter);
		foreach (@params) {
			#remove whitespaces
			$_ =~ s/^\s|\s$//;
			#remove param
			$rumpf =~ s/\b$_\b//g;
		}
		
		#get fkt-name
		#if ($rumpf =~ /([A-Za-z0-9_]*)(.*)/) {
		if ($rumpf =~ /(.*?)([A-Za-z0-9_]+)(.*)/) {
			if ($2) { #dann ist es ein Aufruf zu einer Service-Fkt
				push @calledServices, $2."\n" unless (grep {/$2/} @calledServices); #falls noch nicht hinzugef�gt ist 
			}
		}
	}
}

print SAVE @calledServices;

close (SAVE) or die "Closing failure:, $!";

print "finisched";

=cut

=c
$line = "#define COUNTARRAYOUTOFMINMAX_CONT_S16_ComputeMinMaxCount_ASCET(self,array,arraylength,max,min,startindex,endindex) CountArrayOutOfMinMax_cont_S16_VW(&((self)->MinCount),&((self)->MaxCount),(sint16*)(array),arraylength,max,min,startindex,endindex)";
if ($line =~ /#define (.*)_ASCET(\(.*\))\t+(.*)/) {
	print "Makro : $1\nParameter: $2\nInhalt: $3\n";

	my @params = split(/\,/, $2);
	foreach (@params) {
		$_ =~ s/^\s//;
		$_ =~ s/\(|\)//g;
		print "Param : $_\n";
		$line =~ s/\b$_\b//g;
	}
	print "Line after delete : $line\n";
}

=c
my $testFile = "D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h";

open (FH_CODEGEN, "< $testFile") or die "Reading error: $!";
our @codegenh=<FH_CODEGEN>;
close (FH_CODEGEN) or die "Closing failure:, $!";

foreach my $line (@codegenh) 
{
	if ($line =~ /#define (.*)(\(.*\)).*/) {
		print "$1 : $2\n";
	}
}
	
print "finished\n";

=code expand widget
#!/usr/bin/perl
use Tk;
my $mw = new MainWindow;
 
my $frame = $mw->Frame();
 
my $label1 = $frame->Label (-text=>"Mein Name 1");
my $entry1 = $frame->Entry (-width=>60);

my $label2 = $frame->Label (-text=>"Mein Name 2");
my $entry2 = $frame->Entry (-width=>60);

my $button1= $mw->Button(-text=>"Exit",-command=>\&cmd_button);
 
$frame->pack (-side=>"top",-fill=>"x",-expand=>1);

#using -in
$label1->grid (-row => 1, -column => 1, -sticky => 'ew');
$entry1->grid (-row => 1, -column => 2, -sticky => 'ew');

$label2->grid (-row => 2, -column => 1, -sticky => 'ew');
$entry2->grid (-row => 2, -column => 2, -sticky => 'ew');

$frame -> gridRowconfigure(1, -weight => 1);
$frame -> gridRowconfigure(2, -weight => 1);
$frame -> gridColumnconfigure(2, -weight => 1);
 
$button1->pack(-side=>"left",-fill=>"x",-expand=>1);
 
sub cmd_button
{
   $mw->messageBox (-message=>"Progamm wird beendet!");
   exit;
}
MainLoop;
=c
use warnings;

#!/usr/bin/perl
use Tk;
my $mw = new MainWindow;
 
my $frame = $mw->Frame();
my $frame2 = $mw->Frame();
 
my $label1 = $frame->Label (-text=>"Mein Name 1");
my $entry1 = $frame->Entry (-width=>60);

my $label2 = $frame2->Label (-text=>"Mein Name 2");
my $entry2 = $frame2->Entry (-width=>60);

my $button1= $mw->Button(-text=>"Exit",-command=>\&cmd_button);
 
$frame->pack (-side=>"top",-fill=>"x",-expand=>1);

#using -in
$label1->pack ( -side=>"left",-anchor=>'w'); #Nordwest Ecke
$entry1->pack ( -side=>"left",-anchor=>'w',-fill=>"x",-expand=>1);

$label2->pack ( -side=>"left",-anchor=>'w'); #Nordwest Ecke
$entry2->pack ( -side=>"left",-anchor=>'w',-fill=>"x",-expand=>1);
 
$button1->pack(-side=>"left",-fill=>"x",-expand=>1);
 
sub cmd_button
{
   $mw->messageBox (-message=>"Progamm wird beendet!");
   exit;
}
MainLoop;

=c -> Tooltip
use Tk;
use Tk::Balloon;

  sub HasElem (@$) {
  	my @array = shift;
  	my $elem = shift;
  	
  	foreach (@array) {
  		if (/$elem/i) {
  			return 1; #contains element, dont add
  		} 
  	}
  	
		return 0; #nope, not inside  		
  }
  
my @testArr = qw ("DIAG_GETPERMISSION", "DIAG_GETPERMISSION", "DIAG_REPORT");
  	#while (defined (my $Text = <CFILE>)) {
  		
  	foreach my $Text (@testArr) {	
  		#Suche nach DIAG_Klassen, die BOOL zur�ckgeben (wegen Warnung OVFL int8 zu int1 in Polyspace)
      if ($Text =~ /DIAG_GETPERMISSION|DIAG_REPORT|DIAG_GETSTATICDISABLE|DIAG_GETMIL|DIAG_GETWRNLMP/)
      {
      	if ($Text =~ /DIAG_GETPERMISSION/) {
      		my $isIn = HasElem(@DIAGS, $Text);
      		if ( $isIn == 0 ) {
      			push @DIAGS, "getPermission.return";
      		}  
      	} elsif ($Text =~ /DIAG_REPORT/) {
      		my $isIn = HasElem(@DIAGS, $Text);
      		if ( $isIn == 0 ) {
      			push @DIAGS, "diag_report.return";
      		}
      	} elsif ($Text =~ /DIAG_GETSTATICDISABLE/) {
      		my $isIn = HasElem(@DIAGS, $Text);
      		if ( $isIn == 0 ) {
      			push @DIAGS, "diag_getStaticDisable.return";
      		}
      	} elsif ($Text =~ /DIAG_GETMIL/) {
      		my $isIn = HasElem(@DIAGS, $Text);
      		if ( $isIn == 0 ) {
      			push @DIAGS, "diag_getMIL.return";
      		}
      	} elsif ($Text =~ /DIAG_GETWRNLMP/) {
      		my $isIn = HasElem(@DIAGS, $Text);
      		if ( $isIn == 0 ) {
      			push @DIAGS, "diag_getWrnLmp.return";
      		}
      	}
      }
  	}
  	print "@DIAGS\n";

=c
$mw = MainWindow->new(-title => "Simple Balloon example");
$button = $mw->Button(-text => "Exit", -command => sub { exit })->pack;
$msgarea = $mw->Label(-borderwidth => 2, -relief => 'groove')
  ->pack(-side => 'bottom', -fill => 'x');
$balloon = $mw->Balloon(-statusbar => $msgarea);
$balloon->attach($button, -balloonmsg => "Exit the App",  
  -statusmsg => "Press the Button to exit the application");
$balloon->attach($msgarea, -msg => 'Displays the help text for a widget');
MainLoop;

=c

my $z = "12332";
if ($z =~ /([0-9]*)/ ) {
	print $1, "\n";
}


my $txt = "	arraySize = cDefine EduModl_idxMax_t1_SC_VW;";
if ($txt =~ /cDefine\s(.*);/ ) {
	print $1;
}


=c hashes
my %tgs;

#$tgs{Matrix} =  [12, 13];
@tmpMtr = (12, 13);
$tgs{Matrix} = \@tmpMtr;

@tmpArr = (4);
$tgs{Array} = \@tmpArr;

foreach my $key ( keys %tgs )  {
    print "Articles in group $key are: ";
    my @tmp = @{$tgs{$key}};
    foreach (0..$#tmp)  {
	    print @{$tgs{$key}}[$_];
    }
    print "\n";
}


=code

#$hfilename = "PtTqLoss_Data.c";
#print "1-1 matches \n" if $hfilename =~ /_Data\./;

=code : ZIP
$zip = "D:\\cbb\\MiniBuild\\Build\\GNU\\MKS_Persistent\\MINILINK.grl.zip";
$dir = "D:\\cbb\\MiniBuild\\Build\\GNU\\MKS_Persistent";

my $ae = Archive::Extract->new( archive => $zip );
$ae->extract( to => $dir );

print "file extrahiert";

=code : 
$text = "'D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming, D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Data_header, D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Include, D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\IncludesAll,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\ACCUMULATOR,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\ARRAY,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\BITOPERATIONS,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\COUNTER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\DATASPACE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\DEBOUNCE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\DELAY,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\DIAGFCT,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\GRADIENT,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\HYSTERESIS,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\INCLUDE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\INTEGRATORK,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\INTEGRATORT,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\LIMITER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\LOOKUP,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\LOWPASSK,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\LOWPASST,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\MATH,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\MDB,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\MEDIANFILTER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\MEMORY,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\MIXER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\PCR,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\PERMUTATIONS,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\RAMP,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TIMER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\ACCUMULATOR_REL,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\BMASG,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\COUNTDOWN_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\COUNTDOWN_RTE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\COUNTER_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\COUNTER_RTE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\DELTAONESTEP,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\DIFFERENCELIMITER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\DIFFERENCEQUOTIENT,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\DIGITALLOWPASS_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\EDGEBI,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\EDGEFALLING,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\EDGERISING,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\GRADIENTLIMITER,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\HIGHPASST_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\HYSTERESIS,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\INTEGRATORK_REL,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\INTEGRATORT_REL,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\LOWPASSK_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\LOWPASST_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\MAXLOG_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\MEANVALUET_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\MINLOG_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\RSFLIPFLOP,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\SAMPLEANDHOLD_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\STOPWATCH_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\STOPWATCH_RTE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TIMERRETRIGGER_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TIMERRETRIGGER_RTE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TIMER_RE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TIMER_RTE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TURNOFFDELAYSAMPLE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TURNOFFDELAYTIME,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TURNONDELAYSAMPLE,,D:\\cbb\\Sandboxes\\MSG\\1250_VLCAvl\\Codetest22\\incoming\\Modules\\SERVICE\\TL_WRAPPER\\TURNONDELAYTIME,'";
print $text, "\n";
$text =~ s/\,\,/\,/;
print $text, "\n";


chdir ("D:\\cbb\\MiniBuild\\Build\\GNU\\out\\Modules\\DDS");
print "Current dir ", getcwd();
foreach my $cfilename (<*.c>) {
	print "$cfilename\n";		
}


#
$path = qq(D:\\cbb\\Sandboxes\\MSG\\CEPfil_OpmDes\\Codetest\\CEPfil_OpmDes.cfg);
$path =~ s/\\\\/\//g;
print "$path\n";

#
push @testArr, "aa,cc,vv,bb";
push @testArr, "11";
push @testArr, "22, 33";

foreach (@testArr) {
	@tmp = split (/,/, $_);
	@testArrTmp = (@testArrTmp, @tmp);
}
print "@testArrTmp\n$#testArrTmp\n";

#
@array2 = qw(1 2 3 4);

$line = scalar join ",", @array2;
print "$line\n";


#
print "TESTS\n";
	my $headerText = "Config.cfg";
	$headerText =~ s/.cfg//;  
	print $headerText, "\n";

#
print "SPLICE\n";
my @a=("hans","franz","peter", "aaa", "bbb", "ccc");
print "a: @a\n";
splice(@a,1,2,("walter","anna", "123", "456"));
print "a: @a\n";

# Perl grep function is used to filter a list and to return only those elements that match a certain criteria 
# - in other words it filters out the elements which don�t match a condition.
print "GREP\n";

@a=(1,2,3,4,5,6,7,8,9,10,11,12,13);
print grep {$_<10 && $_>5;} @a;

my $anzahl= grep {$_==5;} @a;
print "\nDie 5 ist $anzahl mal enthalten\n";

my @words = qw(John has selected red blue bed);
my $count = grep /ed$/, @words;
print "\$count = $count\n"; 

# initialize an array
my @array = qw(3 4 5 6 7 8 9);
# first syntax form:
my @subArray = grep { $_ & 1 } @array;
# second syntax form
#my @subArray = grep $_ & 1, @array; 
print "@subArray\n";
# displays: 3 5 7 9








