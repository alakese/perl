#use warnings;
#use strict;
use File::Basename;

my $filename2 = dirname("D:/temp/foo/bar/baz.txt");
#print "$filename2\n";

($name,$path,$suffix) = fileparse($filename2,'\.txt');

$name = fileparse($filename2,'\.txt');
$basename = basename($filename2,'\.txt');
$dirname  = dirname($filename2);
print "$dirname\n";


=c
use Time::HiRes qw(usleep);
use Time::HiRes qw(gettimeofday);

my $i = 0;
while($i < 10)
{
	my $timeOld = gettimeofday();
	
	$i++;
	usleep(10000 * $i);
	
	my $timeNew = gettimeofday();
	my $time = $timeNew - $timeOld;	
	print "$time\n";
}

##!/usr/bin/perl -w
#use File::Basename;
#
#print "Programmname $0\n";
#my $path = File::Basename::dirname($0);
#print $path;

=c
my $line = "#define INTEGRATORTENABLED_S8_compute_ASCET(s,in,T,mn,mx,enable)	{if((enable))IntegratorTLimited_S8_VW(&((s)->memory),()(in),()(T),()(mn),()(mx));}";
my $service = "INTEGRATORTENABLED_DELTAT_S16U32";

if ($line =~ /#define *($service) *.*/i)
{
	print $1;
}

=c
use strict;
use warnings;
use Fcntl qw(:flock);
my $lockfile = 'mylockfile';
sub BailOut {
    print "$0 is already running. Exiting.\n";
    exit(1);
}
print "start of program\n";
open(my $fhpid, '>', $lockfile) or die "error: open '$lockfile': $!";
flock($fhpid, LOCK_EX|LOCK_NB) or OnlyOneInstanceMayRun();
print "sleeping 15...\n";
sleep(15);
print "end of program\n";
# Note: lock should be automatically released at end of program,
# no matter how the process is terminated.

=c
use strict;
use warnings;
use Fcntl qw(:flock);
print "start of program\n";
unless (flock(DATA, LOCK_EX|LOCK_NB))
{
    print "This is already running. Exiting.\n";
    exit(1);
}
print "sleeping 15...\n";
sleep(15);
print "end of program\n";
__DATA__
