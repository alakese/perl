=code
								CHAPTER 2 : 
=cut

print system "perl custom3.pl";
print $?, "\n";
print $? >> 8;


#!/usr/bin/perl -w
#use warnings;
#use strict;

# 1 - Strings
print"1-1 Four sevens are ". 4*7 ."\n";
print "1-2 GO! "x3, "\n";
print "1-3 Ba". "na"x4 ,"\n";
print"1-4 Ba". "na"x4*3 ,"\n"; #Output : Ba0, because nananana time 3 is converting nananana to string, which is zero
print "1-5 Ba". "na"x(4*3) ,"\n"; #12 times

print"1-6 Test one: ", "four" eq "six", "\n"; # use cmp, gt, lt for strings
print "1-7 Test two: ", "four" == "six", "\n"; #equals : == takes numeric arguments, which both here are zero because of convertion

$a = "A9"; print ++$a, "\n"; #perl increments strings in ASCII manner - A to B 9 to 0 
$a = "bz"; print ++$a, "\n";

print"A # has ASCII value ", ord("#"),"\n";

# 2 Quotes

print "\n\n QUOTES \n";

print'\tThis is a single quoted string.\n';
print "\tThis is a double quoted string.\n";

print"C:\\WINNT\\Profiles\\\n";
print 'C:\WINNT\Profiles\ ', "\n"; #use space char after Profiles\

print"It's as easy as that.\n";
print '"Stop," he cried.', "\n";

print"'\"Hi,\" said Jack. \"Have you read Slashdot today?\"'\n";
print qq/'"Hi," said Jack. "Have you read Slashdot today?"'\n/;

print qq|'"Hi," said Jack. "Have you read /. today?"'\n|;
print qq#'"Hi," said Jack. "Have you read /. today?"'\n#;
print qq('"Hi," said Jack. "Have you read /. today?"'\n);
print qq<'"Hi," said Jack. "Have you read /. today?"'\n>;



# 3 Error Message

print<<EOF;

This is a here-document. It starts on the line after the two arrows,\n and it ends when the text following the arrows is found at the beginning of a line, like this:

EOF


# 4 - Numbers
print "\n\nNUMBERS\n";

print 25_000_000, " ", 3.141592653589793238462643383279, "\n";
print 25_000_000, " ", - 4, "\n";


# 5 - BOOLEAN
print "\n\nBOOLEAN\n";

print"Is two equal to four? ",          2 == 4, "\n"; #this is undefined, so no result
print "OK, then, is six equal to six? ", 6 == 6, "\n"; #true as 1
print"So, two isn't equal to four? ", 2 != 4, "\n";

print"Compare six and nine? ",   6 <=> 9, "\n"; # -1 right is bigger
print "Compare seven and seven? ",7 <=> 7, "\n"; # 0 both equal
print "Compare eight and four? ", 8 <=> 4, "\n"; # 1 left is bigger

print"Test one: ", 6 > 3 && 3 > 4, "\n";
print "Test two: ", 6 > 3 and 3 > 4, "\n"; # and has lower pre. so interpreted as => print ("Test two: ", 6 > 3) and 3 > 4, "\n"

# Basename 
my $filename1 = basename("/foo/bar/baz.txt",  ".txt");
print "$filename1\n";

my $filename2 = fileparse("/foo/bar/baz.txt", qr/\Q.txt\E/);
print "$filename2\n";



