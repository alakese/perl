=code
								CHAPTER 10 : MODULES
http://blob.perl.org/books/beginning-perl/3145_Chap10.pdf
=cut

#!/usr/bin/perl -w
use warnings;
use strict;

# use, require and do

# 1 - Special subroutine BEGIN
# -> this wont work : push at run time, use at compiler time
# push @INC, "my/module/dir"; #add directory where Wibble.pm is
# use Wibble; #like use "Wibble.pm";

# BEGIN execution is at compiler time
=code
sub BEGIN {
	push @INC, "my/module/dir";
}
use wibble;
=cut

# 2 - Exporter : importing subroutines from the module into the caller's package
# EXPORT
# EXPORT_OK : we can import subroutines which a module prepared to export, this ll be defined in EXPORT_OK

# Example package which exports the subroutines wobble(), bounce() and boing
=code
package Wibble;
use warnings;
use strict;

use Exporter;
our @ISA = qw(Exporter);
our @EXPORT_OK = qw(wobble bounce boing);  
our @EXPORT = qw(bounce); ----> if no params r passed, we get the default subroutines, which r defined in @EXPORT

sub wobble {...};
sub bounce {...};
sub boing {...};
=cut
# if we call "use Wibble" -> we can call only bounce() without :: -> means we can call wobble() as Wibble::wobble();
# if we call "use Wibble("wobble", "bounce", "boing"), we can call them all, if defined in EXPORT_OK

# After we define "use Wibble", no subroutines will be imported, unless they r defined in EXPORT
# as soon as we call Wibble::bounce(), the subroutine bounce() will be imported

# 3 - Standard perl modules

# File::Find
=code
use File::Find;
find(\&testFind, "D:\\cbb"); #use callback testFind

sub testFind {
	# $_ : name of the current file 
	print "Directory : $_\n" if (-d);
	print "File : $_\n" if (-f);
}

find ( \&callback, "/") ;
sub callback {
   unlink $_ if /\.bak$/;
}

=cut

# Getopt::Std : get command options like -v, -h
# Getopt::Long : like --version, --help

use Getopt::Std;
use Getopt::Long;

#my %singleOptions; #getopt needs a hash
#my %longOptions;
=code
getopts("vhl:", \%singleOptions); #-v, -h and -x : -x takes an argument 
if ($singleOptions{v}) {
	print "Called -v : Version\n";
} elsif ($singleOptions{h}) {
	print "Called -h : Help\n";
} elsif ($singleOptions{l}) {
	print "Called -l : Language $singleOptions{l}\n";
}
=cut
# GetOpt::Long
=code
GetOptions(\%longOptions, "language:s", "help", "version");
if ($longOptions{version}) {
	print "Called --version : Version\n";
} elsif ($longOptions{help}) {
	print "Called --help : Help\n";
} 
=cut
# Version 2 von GetOpt::Long
=code
my @options;
GetOptions("language:s" => \$options[0], "help" => \$options[1], "version" => \$options[2]);

if ($options[2]) {
	print "Called --version : Version\n";
} elsif ($options[1]) {
	print "Called --help : Help\n";
}
=Cut


=code
use Getopt::Long;
my %options;
GetOptions(\%options, "language:s", "help", "version");

if ($options{version}) {
   print "Hello World, version 3.\n";
   exit;
} elsif ($options{help}) {
   print <<EOF;

$0: Typical Hello World program

Syntax: $0 [�-help|--version|--language=<language>]

   --help     : This help message
   --version  : Print version on standard output and exit
   --language : Turn on international language support.
EOF
   exit;
} elsif ($options{language}) {
   if ($options{language} eq "french") {
      print "Bonjour, tout le monde.\n";
   } else {
      die "$0: unsupported language\n";
   }
} else { 
   print "Hello, world.\n";
}
=cut












