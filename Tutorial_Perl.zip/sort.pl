my $input = shift;
my $output = shift;

if (defined $input) {
	open INPUT,  "< $input" or die "Can't open file $input...! $!\n";
} else {
	*INPUT = *STDIN; # * : globs, look like pointers
}

if (defined $output) {
	open OUTPUT, "> $output" or die "Can't open file $output...! $!\n";	
} else {
	*OUTPUT = *STDOUT;
}

my @fileData = <INPUT>;

#perl x.pl Chapter6_4.txt Chapter6_4_sort_ascii.txt
@fileData = sort @fileData; #ascii sort on arrays

print OUTPUT @fileData;