=code
									CHAPTER 7 : REFERENCES
https://docs.google.com/viewer?url=http://blob.perl.org/books/beginning-perl/3145_Chap07.pdf
=cut

#!/usr/bin/perl -w
use warnings;
use strict;

# 1 - Creating References


# a) Variable already defined - create reference by putting a backslash
my @array = (1, 2, 3, 4, 5);
my $array_r = \@array; # my $hash_r = \%hash; OR my $scalar_r = \$scalar

my $a = 3;
my $b = 4;
my @refs1=(\$a, \$b); # a list of references
my @refs2 = \($a, $b); # a list of references, not ref to the list : use array to ref to a list

my @english = qw(january february march);
my @french = qw(janview fevrier mars);
my %months = (english => \@english, french => \@french); 

my @array1 = qw(10 20 30);
my @array2 = (1, 2, \@array1, 4);

# b) Anonymous references - Anonymous data : data that doesnt have a variable name attached to it, like literal

# use [] to ref an array
# use {} to ref a hash

# instead of referencing like this : my $array_r = \@array;
my $array_r2 = [1, 2, 3, 4, 5];
my $hash_r = {english => \@english, french => \@french};

my %months2 = (
	english => ["jan", "..."],
	french 	=> ["Jan", "..."]
);

# ref inside ref
my @array3 = ( 100, 200, [ 2, 4, [ 1, 2 ] ] );


# 2- Using references - dereferencing

my @de_array = @{$array_r};

foreach (@{$array_r}) {
	print "An element : $_\n";
}

# 2-a Array Elements
my @band = qw(aaa sss ddd fff);
my $ref = \@band;

for (0..3) {
	print "Array : $band[$_]\n";
	print "Refer : ${$ref}[$_]\n"; # -> $ref with brackets
}


# 3 - Reference modification

pop @{$ref}; # -> $ref with brackets
print "Array : @band\n";


# 4 - Hash references

my %hash = ( 1 => "jan", 2 => "feb" );
my $href = \%hash;
for (keys %{$href}) {
	print "Key : ", $_, "\t";
	print "Hash: ", $hash{$_}, "\t";
	print "Ref : ", ${$href}{$_}, "\t";
	print "Ref_ : ", $href->{$_}, "\n";
}

# 5 - Notation Shorthands
# you dont have to write the curly brackets
# foreach (@{$array_r}
# for (keys %$href)

# u can use ->
my $ref2 = [1, 2, [10, 20] ];
#my $inside = ${$ref2}[2];
#my $element = ${$inside}[1];
my $element = ${${$ref2}[2]}[1];
print "Element : $element\n";

# instead of ${$ref}, we can say $ref->
$element = $array_r->[0];

$element = $ref2->[2]->[0];
print "Element : $element\n";

$element = $ref2->[2][0];
print "Element : $element\n";


# 6 - Reference counting and destruction
# every piece of data has ref.count attached to it, if 0 data removed

{
	my @array = (1, 2, 3); 	# ref count 1 -> first reference
	$ref =\@array; 			# ref count 2
	my $ref2 = \@array;		# ref count 3 -> ref to string, not an array
	$ref2 = "Hello";		# ref count 2
}							# ref count 1 -> block ends
undef $ref;					# ref count 0 


# 6-1 - Counting anonymous references
my $ref3 = [1, 2, 3]; # -> count 1

my $array3 = (1, 2, 3);
$ref3 = \@array3; # -> hier count 2


# 7 - Matrices : see chess in tutorials
# $array[$row]->$[column] 


# 8 - Autovivification : things springing into existence
# if we assign values to a reference, perl will automatically create all appropriate references necessary to make it work
my $ref4;
$ref4->{UK}->{England}->{Oxford}->[1999]->{Population} = 500000;


# 9 - Trees

# with an example addressbook

# add entry
my %addressbook;
$addressbook{"Jay Way"} = { 
	address => "23, Blue Jay Way",
	phone => "404-4044"
};

# print entry
my $who = "Jay Way";
if (exists $addressbook{$who}) {
	print "$who\n";
	print "Address: ", $addressbook{$who}->{address}, "\n";
	print "Phone : ", $addressbook{$who}->{phone}, "\n";
}

# delete entry 
delete $addressbook{$who};

# add friend
$addressbook{"Jay Way"} = { 
	address => "23, Blue Jay Way",
	phone => "404-4044",
	friends => [ "Jay Way 2", "Jay Way 3" ]
};

# print friends
my @friends = @{$addressbook{$who}->{friends}};
foreach (@friends) {
	print "$_\n";
}

# 10 - LinnkedList




