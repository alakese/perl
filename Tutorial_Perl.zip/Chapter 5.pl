=code
								CHAPTER 5 : REGULAR EXPRESSIONS
https://docs.google.com/viewer?url=http://blob.perl.org/books/beginning-perl/3145_Chap05.pdf
=cut

#!/usr/bin/perl -w
use warnings;
use strict;

$_ = q ("I wonder what the Entish is for yes and no,' he thought.");

# 1 - Searching for a word
print "1-1 matches \n" if $_ =~ /for/; # "for" found
print "1-2 matches \n" if (/what/); # "what" found, compared to $_
print "1-3 matches \n" if $_ !~ /fish/; # no "fish" in text


# 2 - Case sensitivy
print "2-1 not matches \n" unless /entish/; # "entish" not in text
print "2-2 matches \n" if /entish/i; # "entish" with -i


# 3 - Interpolation of variables and metacharacters
my $pattern = "Entish";
print "3-1 matches \n" if /$pattern/;


# Characters with spec. meanings ==> . * ? + [ ] ( ) { } ^ $ | \
# 4 - Turn special meanings of characters off 
print "4-1 matches \n" if /Ent+/; #spec. char. + 
print "4-2 not matches\n" unless /\QEnt+\E/; #no spec. char. here, looking for "Ent+"
print "4-3 not matches\n" unless /for{2}/; #looking for the word "forr"
print "4-4 not matches\n" unless /(for){2}/; #looking for the word "forfor"

# 5 - Anchors
# 	^ : at the beginning of the string
#   $ : at the end of the string
print "5-1 matches \n" if /.$/; #. at end? 
print "5-2 not matches \n" unless /^I/; # is there a "I" at beginning => no because at beginning is a " char before I

#words with "aa" at end
#my @array = qw(aaa bbb ccc daa baa caa);  
#foreach my $elem (@array) {
#	print "$elem\n" if ($elem =~ /aa$/);
#}


# 6 - Shortcuts (\d, \w, \s, \D, \W, \S) and Options
print "6-1 matches \n" if /w[aoi]nder/; #wander, wonder or winder
print "6-2 not matches \n" unless /th[^eo]/; #neither the nor tho 
print "6-3 not matches \n" unless /[0-9]/; #is there a digit?
print "6-4 matches \n" if /\w\w\w\w\w/; #matches any word with AT LEAST 5 letters => found by "wonder"
print "6-5 not matches \n" unless /\s\w\w\w\w\w\s/; #no word with 5 letters \space\word..\word\space
print "6-6 not matches \n" unless /\s\w\s/; #for ex. "I" with \space word \space not matches 
print "6-7 matches \n" if /\b\w\b/; #found "I" with boundary "\b"
print "6-8 matches \n" if /t.....t/; # . : any chars -> w \any two chars then t


# 7 - Alternatives
print "7-1 matches \n" if /yes|maybe/; #yes or maybe
print "7-2 matches \n" if /ye(s|t)/; #yes or yet
print "7-3 not matches \n" unless /th(is|at|e other)/; #this, that or the other
print "7-4a matches \n" if /the(\s|[a-z])|or/; #either "the" followed by space or a letter OR "or"
print "7-4b matches \n" if /the[\sa-z]|or/; #either "the" followed by space or a letter OR "or"


# 8 - Repetition
# 8-1 - Indefinite Repetition

print "8-1 matches\n" if /\bs?he\b/; # ? : something maybe there or may not! -> looking for he or she 
print "8-2 matches\n" if /what the Entish (word )?is/; # 'what the Entish is' or 'what the Entish word is' => after word there must be a space : (word ) OR (word\s) 
print "8-3 matches\n" if /\b\w+\b/; # + : match a word with any length -> first one ist 'I'
print "8-4 not matches\n" unless /^\s*[A-Z]/; # * : zero OR one OR many times -> because of quote at beginning

# 8-2 - Well-Defined Repetition
print "8-5 not matches\n" unless /\s{2,3}/; #min 2 max 3 times spaces e.g {2, }:means two or more, { ,3} 3 or fewer
print "8-6 not matches\n" unless /\b\w{5}\b/; #word with five letters


# 9 - Backreferences
# $1, $2, $3, ... $n : words, which are found, IF reg.exp. defined in a paranthesis
print "9-1 found : $1\n" if /(\b\w\b)/; #with paranth. : $1 stored 
print "9-2 found : $1\n" if /\b\w\b/;  #without paranth. : problem with $1 -> error 'use of uninit...'

$_ = '1: A silly sentence (495,a) *BUT* one which will be useful. (3)';

=code
ENGINE RULES:
1. engine matches as long as it can, stops if not match
2. engine is eager : starts as soon as apossible, finish as quickly as possible
3. engine is greedy : use + OR *, it try and steal as much string as possible (PS: use ?, it's non-greedy)
4. engine hates decisions : two branches -> choose first one
=cut

print "9-3 found : $1\n" if /([a-z]+)/;
print "9-4 found : $1\n" if /(\w+)/;
# 9-5 first two groups match the whole string. 
# But the engine must find something for the the third group (at least one letter), which is in this case the 'l' for [a.z]+
print "9-5 found : \$1 : $1 - \$2 : $2 - \$3 : $3\n" if /([a-z]+)(.*)([a-z]+)/;  
print "9-6 found : \$1 : $1 - \$2 : $2 - \$3 : $3\n" if /([a-z]+)(.*?)([a-z]+)/; # with ? the engine prefers the space char.
print "9-7 found : \$1 : $1 - \$2 : $2 - \$3 : $3\n" if /([a-z]+?)(.*?)([a-z]+?)/; # all smallest possible matches for three groups
print "9-8 found : $1\n" if /e(\w|n\w+)/; # e followed by any word or n+ : $1 has 'n' because of ()


# 10 - Working with RegExps
$_ = "Awake! Awake! Fear, Fire, Foes! Awake! Fire, Foes! Awake!";

# 10-1 - Substitution : s///
# $_ =~ s/Foes/Flee/;
s/Foes/Flee/; #replace first occurrence
print "10-1 replaced : ", $_, "\n";
s/Foes/Flee/g; # /g : replace all occurrences
print "10-2 replaced : ", $_, "\n";

$_ = "there are two major bla mla"; #swap the first two words
s/(\w+)\s+(\w+)/$2 $1/;
print "10-3 replaced : ", $_, "\n";
s/(\w+)\s+(\w+)/$2 $1/g;
print "10-4 replaced : ", $_, "\n";

# 10 - 2 Delimiter
# <>, (), {} and [] may be used instead of // : but what s about 'm' ??
# e.g working with paths
$_ = qq(the path is /usr/local/share/ not /Usr/Local/Share/);
s {/usr/local/share/}
  {/usr/local/}gi;
# s#/usr/local/share/#/usr/local/#; OR -> ; .......... better then s/\/usr\/local\/share\//\/usr\/local\/
print "10-5 replaced : ", $_, "\n";


# 11 - Modifiers

# /m : multiplelines
$_ = "one\ntwo";
print "11-1 not matches\n" unless /^two$/;
print "11-2 matches\n" if /^two$/m;

# /s : singleline
# /g : globally (all occurrences)
# /x : allow the use of whitespace and comments inside a match


# 12 - Split

my $passwd = "kake:x:10018:10020::/home/kake:/bin/bash";
#my @fields = split /:/, $passwd;
#print "12-1 Login name : $fields[0]\n";
#print "12-1 Home dir : $fields[5]\n"; #with :: in middle


# 13 - Join
#my $passwd2 = join "#", @fields:
# print "Original password : $passwd\n";
# print "New password : $passwd2\n";

my @array = qw(1 2 3 4 5 6);
print "13-1 ", @array, "\n";
my $sca = join "#", @array;
print "13-2 ", $sca, "\n";


# 14 - Transliteration
my $test = "2011064";
my $count = $test =~ tr/0-9/a-j/; #translate 2011064 to cabbage
print "14-1 tr : $test, number of letters : $count\n";
#14-2 tr can be use to count some chars, no correlation here because the second argument is blank, so no substitution here
print "14-2 number of vowels in $test is ", $test =~ tr/aeiou//, "\n"; 
#14-3 tr can delete occurrences of some chars in a string
$test =~ tr/aeiou//d;
print "14-3 vowels deleted : $test \n";

# 15 - More advanced topics (see beginning-perl)
$_ = "One Way to do it";

# 15-1 - Inline Comments
print "15-1 found\n" if /One(?# this will be ignored hopefully) Way/; #look for 'One Way' without comment inside

#15-2 Inline modifiers :/i, /m, /s, /x
print "15-2 found \n", if /(?i)one way/; #ignore case sensivity
print "15-3 not found\n" unless /(?-i)one way/i; #don't ignore case sensivity at all (?-i)

#15-3 Grouping without Backreferences
# if we use () these will be stored in variables $1, $2, ... if we dont want to store but group, we use ? 
$_ = "Topic: the weather is ...";
/(X-)?Topic: (\w+)/;
print "15-4 \$1 : $1 - \$2 : $2\n"; #(X-) will be stored too, but we dont want to store it
/(?:X-)?Topic: (\w+)/;
print "15-5 \$1 : $1 - \$2 : $2\n"; #now there s no more $2 

#15-4 Lookaheads and Lookbehinds

# lookahead
$_ = "fish cake and fish pie : cake";
s/fish(?= cake)/CREAM/; #substitute all "FISH"es in a string IF the next word is CAKE 
print "15-4 ", $_, "\n";
$_ = "fish cake and fish pie : cake";
s/fish(?! cake)/CREAM/; #substitute all "FISH"es in a string IF the next word IS NOT the word CAKE 
print "15-5 ", $_, "\n";

# lookbehind
$_ = "fish cake and fish pie : cake";
s/(?<=fish) cake/ CREAM/; #substitute all "CAKE"s in a string IF the previous word is "FISH" 
print "15-6 ", $_, "\n";
$_ = "fish cake and fish pie : cake";
s/(?<!fish) cake/ CREAM/; #substitute all "CAKE"s in a string IF the previous word IS NOT "FISH"
print "15-7 ", $_, "\n";

#15-5 Backreferences (again)
#repeated word
$_ = "tell me a way way to see the way";
if (/\b(\w+)\s\1\b/) {
	print "15-8 Repeated word is : $1"; 
}

















