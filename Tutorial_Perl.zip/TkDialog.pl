##
#		Tk : Windows
##

##
# -> pack();. This will pack the widget '$label' into the window '$mw' : 'pack' is a geometry manager. 
# Another geometry manager is 'grid'. 
##

 
=c
use warnings;
use strict;

use Tk;

my $mw = new MainWindow;

my $minilinkPath;
my $polyspacePath;
my $configFile;

my $frame = $mw -> Frame();

my $labelMinilink = $frame -> Label(-text=>"Minilink Pfad : ") -> grid (-row => 1, -column => 1);
my $entryMinilink = $frame -> Entry(-width => 100) -> grid (-row => 1, -column => 2);
my $buttonMinilink = $frame -> Button(-text => " ... ", -command => \&getMinilinkPath)-> grid (-row => 1, -column => 3);

my $labelPolyspace = $frame -> Label(-text=>"Polyspace Pfad : ") -> grid (-row => 2, -column => 1);
my $entryPolyspace = $frame -> Entry(-width => 100) -> grid (-row => 2, -column => 2);
my $buttonPolyspace = $frame -> Button(-text => " ... ", -command => \&getPolyspacePath)-> grid (-row => 2, -column => 3);

my $labelConfigfile = $frame -> Label(-text=>"Polyspace Config-Dateiname : ") -> grid (-row => 3, -column => 1);
my $entryConfigfile = $frame -> Entry(-width => 100) -> grid (-row => 3, -column => 2);

$frame->pack();

my $frame2 = $mw -> Frame();

my $buttonOK = $frame2 -> Button(-text => "OK", -command => \&onButtonOK)-> grid (-row => 1, -column => 2);
my $buttonCANCEL = $frame2 -> Button(-text => "Cancel", -command => \&onButtonCancel)-> grid (-row => 1, -column => 3);

$frame2->pack();

sub onButtonCancel {
	exit;
}

sub onButtonOK {
	$minilinkPath = $entryMinilink->get();
	if ($minilinkPath eq "") {
		$mw->messageBox (-message => "Bitte geben Sie den Minilink-Pfad ein!", -type => 'OKCancel');
		return;
	}
		
	$polyspacePath = $entryPolyspace->get();
	if ($polyspacePath eq "") {
		$mw->messageBox (-message => "Bitte geben Sie den Polyspace-Pfad ein!", -type => 'OKCancel');
		return;
	}
	
	$configFile = $entryConfigfile->get();
	if ($configFile eq "") {
		$mw->messageBox (-message => "Bitte geben Sie einen Dateiname ein!", -type => 'OKCancel');
		return;
	}
	
	# check and add .cfg at the end of filename
	unless ($configFile =~ /.cfg$/) {
		$configFile = $configFile."\.cfg";
	}
	
	my $messageText = "$minilinkPath\n$polyspacePath\n$configFile";
	$mw->messageBox (-message=>"$messageText", -type => 'OK');
}

sub getPolyspacePath {
	if ($entryPolyspace -> get() ne "") {
		$entryPolyspace -> delete (0, 'end');
	}
	
  	# Erlaubte Datentypen f�r Open-Dialog festlegen
  	my $FileTypes = [ ['C Quelltext', '.c'], ['Alle Dateien', '*']];

  	# Open-Dialog erzeugen und Pfad zur�ckgeben
    my $DIR_Temp = $mw->chooseDirectory(-title  => ['Bitte Polyspace-Verzeichnis (GNU!) ausw�hlen'], -initialdir => "C:\\Temp");
	
	if (defined $DIR_Temp) {
		$entryPolyspace -> insert('end', $DIR_Temp);
	}
}

sub getMinilinkPath {
	if ($entryMinilink -> get() ne "") {
		$entryMinilink -> delete (0, 'end');
	}
	
  	# Erlaubte Datentypen f�r Open-Dialog festlegen
  	my $FileTypes = [ ['C Quelltext', '.c'], ['Alle Dateien', '*']];

  	# Open-Dialog erzeugen und Pfad zur�ckgeben
    my $DIR_Temp = $mw->chooseDirectory(-title  => ['Bitte Minilink-Verzeichnis (GNU!) ausw�hlen'], -initialdir => "C:\\Temp");
	
	if (defined $DIR_Temp) {
		$entryMinilink -> insert('end', $DIR_Temp);
	}
}

MainLoop;

=code
# 1. pack
foreach (qw/Vorname Nachname Strasse PLZ Ort/) {
       $mw->Label(-text => $_)->pack();
       $mw->Entry(-textvariable => \$results{$_},
       				-width => 50)->pack();
}
$mw->Button(-text => "Ok", -command => sub { print "$_ => $results{$_}\n" for keys %results })->pack();
#
my $button2 = $mw->Button(-text => "Exit", -command => \&myExit );
$button2->pack(-side => "right", -anchor=>'w');

sub myExit {
	exit;
}

MainLoop();

# 2. grid
=code
my %vars;

foreach(qw/An: Von: Betreff:/) {
    $mw->Label(-text => $_)->grid($mw->Entry(-textvariable => \$vars{$_}));
}

$mw->Button(-text    => 'send', -command => sub { print "$_ ->> $vars{$_}\n" for keys %vars; })->grid();
		
MainLoop();