=code
								CHAPTER 3 : Arrays and hashes
=cut

# 1 - Arrays
print "1. ARRAYS\n";

# Looping arrays 1
my @array=(10, 20, 30, 40);
print "Before: @array\n";
for (@array) { $_ *= 2 } #alias
print "After: @array\n";

#Looping arrays 2
my @array = qw(America Asia Europe Africa);
my $element;
for $element (@array) {
	print $element, "\n";
}

# Array : max num of elem
my @questions = qw(Java Python Perl C);
for (0..$#questions) {
	print $questions[$_]; # $_ has the number 0 .. max
}

# Array funtions - sort
my @unsorted = qw(Cohen Clapton Costello Cream Cocteau);
print "Unsorted: @unsorted\n";
my @sorted = sort @unsorted;
print "Sorted:   @sorted\n";

# Sort for nums and strings : <=>
my @unsorted = (1, 2, 11, 24, 3, 36, 40, 4);
my @string = sort { $a cmp $b } @unsorted;
print "String sort:  @string\n";
my @number = sort { $a <=> $b } @unsorted;
print "Numeric sort:  @number\n";

# Scalar context - Array context 1
my @array1;
my $scalar1;
@array1 = qw(Monday Tuesday Wednesday Thursday Friday Saturday Sunday);
$scalar1 = @array1; #as scalar it returns the number of elements in an array
print "Array is @array1\nScalar is $scalar1\n";

# Scalar context - Array context 2 : forcing to be a scalar
print "Scalar value   : ", scalar @array, "\n";
print "Highest element: ", $#array, "\n";

# Accessing multiple elements
my @sales = (69, 118, 97, 110, 103, 101, 108, 105, 76, 111, 118, 101);
my @months = qw(Jan Feb Mar May Apr Jun Jul Aug Sep Oct Nov Dec);

print "Second quarter sales:\n";
print "@months[3..5]\n@sales[3..5]\n";
my @q2=@sales[3..5];

# Acceesing the last elem
my @q3=@sales[-3..-1]; #last three element

# Incorrect results in May, August, Oct, Nov and Dec!
@sales[4, 7, 9..11] = (68, 101, 114, 111, 117);

# Swap April and May
@months[3,4] = @months[4,3];


# 2 - Hashes
print "\n\n2. HASHES\n";

my %where=(
        Gary     => "Dallas",
        Lucy     => "Exeter",
        Ian      => "Reading",
        Samantha => "Oregon"
);

# Loop keys : values as same
for (keys %where) {
	print "$_ lives in $where{$_}\n";
}

# Delete entry
delete $where{Lucy};
print "Lucy lives in $where{Lucy}\n";

# reverse the hash : keys must have unique id, in orderto revers keys-values
my %who = reverse %where;





















