=code
								CHAPTER 4 : Loops and decisions
=cut

# LOOPS

# Looping arrays 1
my @array = (1..10);
foreach (@array) { #or for (@array) ...
	$_++;
}
print "1 - Array is now: @array\n";

# 2
my @array = (1, 3, 5, 7, 9);
print "2 - ";
foreach my $j (@array) { #if u declare inner, new variable ll be created
	print "$j ";
}
print "\n"; 

# 3
print "3 - ";
my $i="Hello there"; #if u declare iterator outside the loop, old value ll be restored after the loop ends
foreach $i (@array) {
	print "$i ";
}
print "\n3 - All done: $i\n";

# 4 
print "4 - ";
for my $i (@array) {
	print "$i ";
}

# 5 - 
my $total=0;
$total += $_ for @ARGV;
print "The total is $total\n";

# 6 - last
my @array = ( "red", "blue", "STOP THIS NOW", "green");
for (@array) {
	last if $_ eq "STOP THIS NOW";
	print "Today's colour is $_\n";
}

# 7 - next
my @array = (8, 3, 0, 2, 12, 0);
for (@array) {
	if ($_ == 0) {
		print "Skipping zero element.\n";
		next;
	}
	print "48 over $_ is ", 48/$_, "\n";
}

# 8 - Labels
my @getout = qw(quit leave stop finish);

OUTER: while (<STDIN>) {
	chomp;
	INNER: for my $check (@getout) {
		last OUTER if $check eq $_;
	}
	print "Hey, you said $_\n";
}


# DECISIONS

# 1 - Value defined

my ($a, $b);
$b = 10;
if (defined $a) {
	print "\$a has a value.\n";
}
if (defined $b) {
	print "\$b has a value.\n";
}

# 2 - if - unless (if not)
# die "I don't know anything about $to as a currency\n" unless exists $rates{$to};


# 3 - while - until (while (not true))
while (<STDIN>) {
	chomp;
	last unless $_;
	my $sdrawkcab = reverse $_;
	print "$sdrawkcab\n";
}

#
my $countdown = 5;

until ($countdown-- == 0) {
	print "Counting down: $countdown\n";
}

# 4 - 






