use warnings;
#use strict;
use Text::ParseWords;


=c
open (FH_CODEGEN, "< D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h") or die "Reading error: $!";
my @file = <FH_CODEGEN>;
close (FH_CODEGEN) or die "Closing failure:, $!";

open (SAVE, "> C:\\Dokumente und Einstellungen\\ealakes\\Desktop\\new2.c") or die "Reading error: $!";

foreach my $line (@file) {
	if ($line =~ /OR_U8_or_ASCET/) {
		print "oks\n";
	}
	
	$line =~ s/^\s*//;
	if ($line =~ /^\/\*|^\*/) {
		next;
	}

	print SAVE $line;
}

close SAVE;

print "ok";
=c
my $services = "D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_services.h";

open (SERVICESW, "$services") or die;
my @services; 
while (defined (my $line = <SERVICESW>)) {
	if ($line =~ /^#include\s*\"(.*).c/)
	{
		chomp $line;
		push @services, $1;
	}
}
close SERVICESW;

$searchTxt = "LowpassT_dT_S16_VW";

#print @services;

if ( grep {/\b$searchTxt\b/} @services ) {
	print "Found : $searchTxt\n";
}

print "Found?\n";

=c
use warnings;
use strict;
use Text::ParseWords;

my $services = "D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_services.h";
#my $types = "uint8|uint16|uint32|sint8|sint16|sint32|real32";
#my $internElements = "counter|buffer|memory|Memory|timeCounter|deltaTvariable|inOld|time|outbit|initValue|oldValue|oldSignal|hysterese|hysteresis|rampActive|PointerArray|tGsCalc|tWallCalc|pwrHeatWallEnvCalc|dstLockStrt|noDrvCycLock|dstLock|gradient|Input_Storage|Index_Counter|MinCount|MaxCount|mem|Nxt|Prs|pos_int";
#my $keywords = "const|if|else|_SC_VW";
#my $nums = "[0-9]*";
#my $octs = "0x[a-fA-F0-9]*";
#my $unsLongs = "[0-9]*UL";

open (SERVICES, "< $services") or die "Cant open : $!";
my @services; 
while (defined (my $line = <SERVICES>)) {
	if ($line =~ /^#include\s*\"(.*).c/)
	{
		chomp $line;
		push @services, $1;
	}
}
close SERVICES;

open (FH_CODEGEN, "< D:\\cbb\\MiniBuild\\Build\\GNU\\Modules\\SERVICE\\INCLUDE\\ASCET_Audi_codegen.h") or die "Reading error: $!";
my @file = <FH_CODEGEN>;
close (FH_CODEGEN) or die "Closing failure:, $!";

open (SAVE, "> C:\\Dokumente und Einstellungen\\ealakes\\Desktop\\new2.c") or die "Reading error: $!";
=c
#remove types
map{s/\b$types\b//g} @file;

#remove intern elems
map{s/\b$internElements\b//g} @file;

#remove keywords
map{s/\b$keywords\b//g} @file;

#remove numbers
map{s/\b$nums\b//g} @file;

#remove ULs
map{s/$unsLongs//g} @file;

#remove octs
map{s/$octs//g} @file;
=cut
#remove params
#my @calledServices;
#
#my $Debug = 0;#
#
#my $i = 0;
#foreach my $line (@file) {
#	next unless ( $line =~ /^#define/);
#	if ($line =~ /PIPE_V2_R32_compute_ASCET/) {
#		$Debug && print "Ok";
#	}
#	
#	print $line, "\n";
#	
#	my @words = quotewords('\s+', 0, $line);
#	
#	foreach my $word (@words)
#	{
#		if ($word =~ /(\w+)/) {
#			#print ($1);
#			if ( (grep {/\b$1\b/} @services) and !(grep {/$1/} @calledServices) ) {
#				push @calledServices, $1."\n";				
#			}
#		}
#	}	
	
=c
	$i++;
	if ($i == 777) {
		$Debug && print "Ok";
	}
	if ($line =~ /TIMERRETRIGGER_DT_U16/) {
		$Debug && print "Ok";
	}
	
	#convert tabs to a space, weil zwischen Parameterende und Inhalt gibt es unterschiedliche leer-spaces
	#$line =~ s/\t+/ /g;
	if ($line =~ /#define (.*)_ASCET(\(.*\))\s+[{()]*(\w+)(.*)/) {
	#if ($line =~ /#define (.*)_ASCET(.*)\s+(\w+)(.*)/) {
		my $macroName = $1;
		my $parameter = $2;
		my $fctName = $3;
		my $inhalt = $4;
		
		if ($3) {
			#Funktionsname hinzuf�gen, falls nicht in der Liste ist
			push @calledServices, $3."\n" unless (grep {/$3/} @calledServices); 	
		}
		
#		my $rumpf = $3;
#		$parameter =~ s/\(|\)//g;
#		my @params = split(/\,/, $parameter);
#		foreach (@params) {
#			#remove whitespaces
#			$_ =~ s/^\s|\s$//g;
#			#remove param
#			$rumpf =~ s/\b$_\b//g;
#		}
#		
#		#get fkt-name
#		#if ($rumpf =~ /([A-Za-z0-9_]*)(.*)/) {
#		if ($rumpf =~ /(.*?)([A-Za-z0-9_]+)(.*)/) {
#			if ($2) { #dann ist es ein Aufruf zu einer Service-Fkt
#				push @calledServices, $2."\n" unless (grep {/$2/} @calledServices); #falls noch nicht hinzugef�gt ist 
#			}
#		}
	}
=cut	#
#}

#print SAVE @calledServices;

#close (SAVE) or die "Closing failure:, $!";

#print "finisched";
=C
use strict; use warnings;

@words = quotewords( '\s+', 0, 
"#define CHGBITPOSN_U08U16_ChgStatus_ASCET(BitPosn,noBitPosn,Status)	(()(()(ChgBitPosn_U32U32_VW(( *)(BitPosn), ()(noBitPosn), ()(Status))) & (ul)))");

$i = 0;
foreach my $word (@words)
{
	print "$i: <$word>\n";
	print $1 if ($word =~ /(\w+)/);
	print "\n";
	$i++;
}

=c
$line = "#define CHGBITPOSN_U08U16_ChgStatus_ASCET(BitPosn,noBitPosn,Status)	(()(()(ChgBitPosn_U32U32_VW(( *)(BitPosn), ()(noBitPosn), ()(Status))) & (ul)))";

#if ($text =~ /(\w*) [()]*(\w*)/) {
if ($line =~ /#define (.*)_ASCET(\(.*\))\s+[{()]*(\w+)(.*)/) {
	print $1, "\n";
	print $2, "\n";
	print $3, "\n";
	print $4, "\n";	
}


=c
my $line = "#define COUNTARRAYOUTOFMINMAX_CONT_S16_ComputeMin_ASCET(self,array,arraylength,max,min,startindex,endindex) CountArrayOutOfMinMax_cont_S16_VW(&((self)->),&((self)->),(*)(array),arraylength,max,min,startindex,endindex)";
if ($line =~ /#define\s(.*)_ASCET(\(.*\))\s(.*)/) {
	print "name:$1\nparam:$2\nrumpf:$3";
	if ($3 =~ /(.*?)([A-Za-z0-9_]+)(.*)/) {
		print $2,"\n";
	}
}
print "finis";

=c
use Tk;

my $mw = new MainWindow;

my $labelMinilink = $mw -> Label(-text=>"Minilink Pfad : ") -> grid (-row => 1, -column => 1);
my $entryMinilink = $mw -> Entry(-width => 100) -> grid (-row => 1, -column => 2, -sticky => 'ew');
my $buttonMinilink = $mw -> Button(-text => " ... ", -command => \&getMinilinkPath)-> grid (-row => 1, -column => 3);

$mw -> gridRowconfigure(1, -weight => 1);
$mw -> gridColumnconfigure(2, -weight => 1);

my $buttonOK = $mw -> Button(-text => "OK")-> pack ();

#my $buttonCANCEL = $mw -> Button(-text => "Cancel", -command => \&onButtonCancel)->  pack (-side => "right");





MainLoop;

=code
# 1. pack
foreach (qw/Vorname Nachname Strasse PLZ Ort/) {
       $mw->Label(-text => $_)->pack();
       $mw->Entry(-textvariable => \$results{$_},
       				-width => 50)->pack();
}
$mw->Button(-text => "Ok", -command => sub { print "$_ => $results{$_}\n" for keys %results })->pack();
#
my $button2 = $mw->Button(-text => "Exit", -command => \&myExit );
$button2->pack(-side => "right", -anchor=>'w');

sub myExit {
	exit;
}

MainLoop();

=code
# 1. pack
foreach (qw/Vorname Nachname Strasse PLZ Ort/) {
       $mw->Label(-text => $_)->pack();
       $mw->Entry(-textvariable => \$results{$_},
       				-width => 50)->pack();
}
$mw->Button(-text => "Ok", -command => sub { print "$_ => $results{$_}\n" for keys %results })->pack();
#
my $button2 = $mw->Button(-text => "Exit", -command => \&myExit );
$button2->pack(-side => "right", -anchor=>'w');

sub myExit {
	exit;
}

MainLoop();

=code
@array1 = qw(aaa aabbb ccaac dddaa eee);
@val = "aa";
@matches = grep( $_ =~ /aa/, @array1 );
print "@matches\n";
=cut

=c
open GENINITS, "D:\\cbb\\Sandboxes\\MSG\\590_CordStrtStop\\cts\\ct1\\working\\Module_1\\Result_2\\geninits.txt" or die $!;
open INPUTS, "D:\\cbb\\Sandboxes\\MSG\\590_CordStrtStop\\cts\\ct1\\working\\Module_1\\Result_2\\inputs.txt" or die $!;

my @gen;
@gen = <GENINITS>;

my @inputs;
@inputs = <INPUTS>;

@sorted = sort @inputs;

print @sorted, "\n-------------------------------\n";

my @res;

foreach my $elemGen (@gen) {
	my $isWritten = 0;
	chomp $elemGen;
	foreach (0 .. $#sorted) {
		chomp $sorted[$_];
		if ($elemGen =~ /$sorted[$_]/) {
			#print $sorted[$_], "\n";
			push @res, $sorted[$_];
			next;
		}
	}	
}

@sortedPushed = sort @res;
print @sortedPushed, "\n\n";

print "finished\n";

close GENINITS;
close INPUTS;

=code
open DDX, "D:\\cbb\\Sandboxes\\PTE\\LWBS_PrmCalc\\ct_sc1\\working\\Module_1\\variddx.txt" or die $!;
open DATA, "D:\\cbb\\Sandboxes\\PTE\\LWBS_PrmCalc\\ct_sc1\\working\\Module_1\\data_h_inits.txt" or die $!;
open RES, "> D:\\cbb\\Sandboxes\\PTE\\LWBS_PrmCalc\\ct_sc1\\working\\Module_1\\result.txt";

my @ddx;
@ddx = <DDX>;

my @data;
@data = <DATA>;

foreach my $elemData (@data) {
	chomp $elemData;
	foreach my $elemDdx (@ddx) {
		chomp $elemDdx;
		my @ddxs = split / /, $elemDdx;
		if ($elemData eq $ddxs[1]) {
			print RES "DDX : $elemDdx - DATA : $elemData\n";
		}
	}	
}

close DDX;
close DATA;
close RES;
=cut

